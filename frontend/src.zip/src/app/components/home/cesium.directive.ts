import { Directive, ElementRef, OnInit } from "@angular/core";
import {
  Ion,
  Viewer,
  createWorldTerrainAsync,
  createWorldImageryAsync,
  createOsmBuildingsAsync,
  SceneMode,
} from "cesium";
import { CesiumManager } from "./modules/cesium-manager-module";
import { environment } from "../../../../environment";

@Directive({
  selector: "[appCesium]",
})
export class CesiumDirective implements OnInit {
  constructor(private el: ElementRef, private manager: CesiumManager) {}

  async ngOnInit() {
    // token
    Ion.defaultAccessToken = environment.cesium_public_token;

    // create viewer (start minimal, add providers after)
    const viewer = new Viewer(this.el.nativeElement, {
      // keep UI light
      geocoder: false,
      homeButton: true,
      sceneModePicker: false,
      baseLayerPicker: false,
      navigationHelpButton: false,
      fullscreenButton: false,

      // animation/timeline only if you really need them
      timeline: true,
      animation: true,
      shouldAnimate: true,

      // PERF: render only when needed (huge boost)
      requestRenderMode: true,
      maximumRenderTimeChange: Infinity,

      // start in 3D
      sceneMode: SceneMode.SCENE3D,
    });

    // Providers (imagery + terrain)
    const terrainProvider = await createWorldTerrainAsync();
    viewer.terrainProvider = terrainProvider;

    const imageryProvider = await createWorldImageryAsync();
    viewer.imageryLayers.removeAll();
    viewer.imageryLayers.addImageryProvider(imageryProvider);

    // Make terrain occlusion correct
    viewer.scene.globe.depthTestAgainstTerrain = false;

    // Optional: reduce some costs
    viewer.scene.fog.enabled = false;

    // Buildings (OSM)
    try {
      const buildings = await createOsmBuildingsAsync();
      viewer.scene.primitives.add(buildings);
    } catch (e) {
      console.warn("OSM Buildings failed to load:", e);
    }

    // Let manager handle drawing + LOD
    this.manager.setViewer(viewer);

    // Initial render
    viewer.scene.requestRender();
  }
}
