import {
  Cartesian3,
  Color,
  SampledPositionProperty,
  VelocityOrientationProperty,
  JulianDate,
  ClockRange,
  Entity,
  Viewer,
  HeightReference,
  ArcType,
  LagrangePolynomialApproximation,
  sampleTerrainMostDetailed,
  Cartographic
} from "cesium";

import { Coordinate } from "../../services/shared.service";

/* ================= CONFIG ================= */

const TERRAIN_OFFSET_METERS = 5;
const POLYLINE_WIDTH = 4;
const POLYLINE_ALPHA = 0.95;
const MOVING_POINT_SIZE = 12;
const CLOCK_REALTIME = 1;
const INTERPOLATION_DEGREE = 1;

/* ================= CACHE ================= */

let cachedKey = "";
let cachedTerrain: number[] | null = null;

/* ================= TYPES ================= */

export type TrajectoryLODHandles = {
  rawPoints: Coordinate[];
  polylineEntity?: Entity;
  movingEntity?: Entity;
  startTime?: JulianDate;
  stopTime?: JulianDate;
};

/* ================= HELPERS ================= */

function altitudeWithOffset(a: number): number {
  return Math.max(0, (a ?? 0) + TERRAIN_OFFSET_METERS);
}

function trajectoryKey(points: Coordinate[]): string {
  // lightweight hash instead of JSON.stringify (faster)
  return `${points.length}-${points[0]?.lat}-${points.at(-1)?.lat}`;
}

async function sampleTerrainCached(
  viewer: Viewer,
  points: Coordinate[]
): Promise<number[]> {

  const key = trajectoryKey(points);

  if (key === cachedKey && cachedTerrain) {
    return cachedTerrain;
  }

  const cartos = new Array(points.length);

  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    cartos[i] = Cartographic.fromDegrees(p.lon, p.lat);
  }

  const updated = await sampleTerrainMostDetailed(
    viewer.terrainProvider,
    cartos
  );

  cachedTerrain = updated.map(c => c.height ?? 0);
  cachedKey = key;

  return cachedTerrain;
}

/* ================= MAIN ================= */

export async function drawTrajectoryLOD(
  viewer: Viewer,
  rawPoints: Coordinate[],
  handles: TrajectoryLODHandles,
  durationSeconds: number
): Promise<TrajectoryLODHandles> {

  if (!viewer || rawPoints.length === 0) return handles;

  viewer.clock.shouldAnimate = false;
  viewer.clock.multiplier = CLOCK_REALTIME;

  handles.rawPoints = rawPoints;

  if (handles.polylineEntity) viewer.entities.remove(handles.polylineEntity);
  if (handles.movingEntity) viewer.entities.remove(handles.movingEntity);

  const terrain = await sampleTerrainCached(viewer, rawPoints);

  /* ---------- polyline ---------- */

  const positions = new Array(rawPoints.length);

  for (let i = 0; i < rawPoints.length; i++) {
    const p = rawPoints[i];

    positions[i] = Cartesian3.fromDegrees(
      p.lon,
      p.lat,
      altitudeWithOffset(p.alt) + terrain[i]
    );
  }

  handles.polylineEntity = viewer.entities.add({
    polyline: {
      positions,
      width: POLYLINE_WIDTH,
      material: Color.CYAN.withAlpha(POLYLINE_ALPHA),
      arcType: ArcType.GEODESIC,
    },
  });

  /* ---------- animation ---------- */

  const property = new SampledPositionProperty();

  property.setInterpolationOptions({
    interpolationAlgorithm: LagrangePolynomialApproximation,
    interpolationDegree: INTERPOLATION_DEGREE,
  });

  const start = JulianDate.now();
  const dt = durationSeconds / Math.max(1, rawPoints.length - 1);

  for (let i = 0; i < rawPoints.length; i++) {

    const p = rawPoints[i];

    const t = JulianDate.addSeconds(start, i * dt, new JulianDate());

    const pos = Cartesian3.fromDegrees(
      p.lon,
      p.lat,
      altitudeWithOffset(p.alt) + terrain[i]
    );

    property.addSample(t, pos);
  }

  const stop = JulianDate.addSeconds(start, durationSeconds, new JulianDate());

  handles.startTime = start;
  handles.stopTime = stop;

  viewer.clock.startTime = start.clone();
  viewer.clock.stopTime = stop.clone();
  viewer.clock.currentTime = start.clone();
  viewer.clock.clockRange = ClockRange.CLAMPED;
  viewer.clock.multiplier = CLOCK_REALTIME;
  viewer.clock.shouldAnimate = true;

  handles.movingEntity = viewer.entities.add({
    position: property,
    point: {
      pixelSize: MOVING_POINT_SIZE,
      color: Color.RED,
      heightReference: HeightReference.NONE,
      disableDepthTestDistance: Number.POSITIVE_INFINITY,
    },
    orientation: new VelocityOrientationProperty(property),
  });

  viewer.trackedEntity = handles.movingEntity;
  viewer.scene.requestRender();

  return handles;
}
