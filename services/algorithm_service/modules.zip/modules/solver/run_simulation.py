# modules/solver/run_simulation.py

import math
from typing import Optional

from modules.dynamics.integrators import rk4_step
from modules.solver.solver_3dof import derivatives
from modules.state.state import State3DOF
from modules.atmosphere.wind import DrydenWindModel

MAX_ABS_VELOCITY = 2e4
MAX_ABS_Q = 1e3
MAX_ABS_THETA = 1e3


def _is_sane(s: State3DOF) -> bool:
    vals = [s.x, s.z, s.vx, s.vz, s.theta, s.q]

    if not all(math.isfinite(v) for v in vals):
        return False

    if abs(s.vx) > MAX_ABS_VELOCITY or abs(s.vz) > MAX_ABS_VELOCITY:
        return False

    if abs(s.q) > MAX_ABS_Q:
        return False

    if abs(s.theta) > MAX_ABS_THETA:
        return False

    return True


def run_simulation(
    state0: State3DOF,
    dt: float,
    max_time: float,
    *,
    wind_model: Optional[DrydenWindModel] = None,
    **params,
):

    t = 0.0
    state = state0
    trajectory = []

    if not _is_sane(state):
        raise RuntimeError("Initial state not sane")

    while t < max_time:

        trajectory.append(state)

        if state.z <= 0.0:
            break

        if wind_model is None:
            wind_x, wind_z = 0.0, 0.0
        else:
            # 🔧 FIX: relative airspeed
            Va = math.hypot(state.vx - wind_model.ut, state.vz - wind_model.wt)
            wind_x, wind_z = wind_model.step(state.z, Va, dt)

        state = rk4_step(
            derivatives,
            state,
            dt,
            wind_x=wind_x,
            wind_z=wind_z,
            **params,
        )

        if not _is_sane(state):
            raise RuntimeError(f"Numerical blow-up detected at t={t:.3f}s")

        t += dt

    return trajectory
