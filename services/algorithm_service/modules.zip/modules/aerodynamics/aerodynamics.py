from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple
import math

from modules.atmosphere.isa import speed_of_sound

DEFAULT_GAMMA = 1.4


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


@dataclass(frozen=True)
class AeroRef:
    Sref: float
    lref: float


def compressible_dynamic_pressure(P: float, M: float, gamma: float = DEFAULT_GAMMA) -> float:
    return 0.5 * gamma * P * (M * M)


def aerodynamic_DLM(
    P: float,
    M: float,
    CD: float,
    CL: float,
    CM: float,
    ref: AeroRef,
    gamma: float = DEFAULT_GAMMA,
) -> Tuple[float, float, float]:

    qbar = compressible_dynamic_pressure(P, M, gamma)

    D = qbar * ref.Sref * CD
    L = qbar * ref.Sref * CL
    Mp = qbar * ref.Sref * ref.lref * CM

    return D, L, Mp


def effective_CM(
    *,
    CM0: float,
    CL: float,
    alpha: float,
    Cm_alpha: float,
    Cmq: float,
    q: float,
    V: float,
    ref: AeroRef,
    lcg: float = 0.0,
) -> float:

    # 🔧 FIX: wider clamp — avoids non-physical moment lock
    alpha_lim = math.radians(45.0)
    alpha_eff = _clamp(alpha, -alpha_lim, alpha_lim)

    q_eff = _clamp(q, -50.0, 50.0)

    V_safe = max(V, 1e-3)

    CM = (
        CM0
        + Cm_alpha * alpha_eff
        + Cmq * (q_eff * ref.lref / (2.0 * V_safe))
        + CL * lcg
    )

    return CM


# ============================================================
# Forces from aerodynamic table
# ============================================================

def compute_Xv_Zv_My_from_table(
    *,
    P,
    T,
    vx,
    vz,
    wind_x,
    wind_z,
    alpha,
    mach,
    coeffs,
    ref,
    q,
    lcg=0.0,
):
    """
    Convert aerodynamic coefficients to forces and moment
    in inertial frame.
    """

    CL, CD, CM = coeffs

    # Relative velocity
    vx_rel = vx - wind_x
    vz_rel = vz - wind_z

    V = math.hypot(vx_rel, vz_rel)

    if V < 1e-6:
        return 0.0, 0.0, 0.0, mach, CM

    gamma = math.atan2(vz_rel, vx_rel)

    rho = P / (287.05 * T)
    qbar = 0.5 * rho * V * V

    # Aerodynamic forces
    D = qbar * ref.Sref * CD
    L = qbar * ref.Sref * CL

    # Convert to inertial frame
    Xv = -D * math.cos(gamma) - L * math.sin(gamma)
    Zv = -D * math.sin(gamma) + L * math.cos(gamma)

    # Moment with damping
    CM_eff = CM + (-0.5 * q * ref.lref / max(V, 1e-3))
    My = qbar * ref.Sref * ref.lref * CM_eff

    return Xv, Zv, My, mach, CM_eff
