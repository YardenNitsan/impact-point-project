# modules/atmosphere/wind.py

import math
import random
from typing import Optional, Tuple

# ============================================================
# Dryden model constants (as used in your reference)
# ============================================================

DRYDEN_A = 0.177
DRYDEN_B = 0.0027
DRYDEN_EXP_L = 1.2
DRYDEN_EXP_SIGMA = 0.4
DRYDEN_VERTICAL_SCALE = 0.1

MIN_ALTITUDE = 1.0   # [m]
MIN_AIRSPEED = 1.0   # [m/s]

GAUSS_MEAN = 0.0
GAUSS_STD = 1.0
TWO = 2.0


class DrydenWindModel:
    """
    Dryden wind turbulence model (discrete).
    Produces turbulence components (ut, vt, wt) in [m/s].
    """

    def __init__(self, Vw_ground: float, seed: Optional[int] = None):
        self.Vw_ground = float(Vw_ground)
        self._rng = random.Random(seed)

        self.ut = 0.0
        self.vt = 0.0
        self.wt = 0.0

    def step(self, z: float, Va: float, dt: float) -> Tuple[float, float]:
        h = max(float(z), MIN_ALTITUDE)
        base = DRYDEN_A + DRYDEN_B * h

        Lu = h / (base ** DRYDEN_EXP_L)
        Lv = Lu
        Lw = h

        sigma_u = self.Vw_ground / (base ** DRYDEN_EXP_SIGMA)
        sigma_v = sigma_u
        sigma_w = DRYDEN_VERTICAL_SCALE * self.Vw_ground

        eta_u = self._rng.gauss(GAUSS_MEAN, GAUSS_STD)
        eta_v = self._rng.gauss(GAUSS_MEAN, GAUSS_STD)
        eta_w = self._rng.gauss(GAUSS_MEAN, GAUSS_STD)

        Va_eff = max(float(Va), MIN_AIRSPEED)

        self.ut += dt * (-Va_eff * self.ut / Lu + sigma_u * math.sqrt(TWO * Va_eff / Lu) * eta_u)
        self.vt += dt * (-Va_eff * self.vt / Lv + sigma_v * math.sqrt(TWO * Va_eff / Lv) * eta_v)
        self.wt += dt * (-Va_eff * self.wt / Lw + sigma_w * math.sqrt(TWO * Va_eff / Lw) * eta_w)

        return self.ut, self.wt
